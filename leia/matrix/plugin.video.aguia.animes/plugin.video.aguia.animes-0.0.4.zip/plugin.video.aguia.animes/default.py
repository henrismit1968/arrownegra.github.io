# -*- coding: utf-8 -*-
import six
import requests
from bs4 import BeautifulSoup
try:
    from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
    kodi_mode = True
except:
    kodi_mode = False
if six.PY3:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode #python 3
else:
    from urlparse import urlparse, parse_qs #python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode
import sys
import os
import re
import base64

# novo update 05/04/2023

def referer_player():
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36 Edg/111.0.1661.41'
    referer = ''
    try:
        r = requests.get('https://onepod.inrupt.net/public/aguia_animes/aguia_animes.txt', headers={'User-Agent': ua})
        src = r.text
        referer = re.findall('referer="(.*?)"', src)[0]
    except:
        pass
    return referer

class scrape:
    site_anime = 'https://meuanime.io'
    referer_player = referer_player()
    headers = {'Connection': 'keep-alive', 
            'sec-ch-ua': '"Microsoft Edge";v="111", "Not(A:Brand";v="8", "Chromium";v="111"', 
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36 Edg/111.0.1661.41',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-User': '?1',
            'Sec-Fetch-Dest': 'document',
            'Accept-Encoding': 'gzip',
            'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6'
            }
    user_agent = headers['User-Agent']
    itag_map = {'5': '240', '6': '270', '17': '144', '18': '360', '22': '720', '34': '360', '35': '480',
    '36': '240', '37': '1080', '38': '3072', '43': '360', '44': '480', '45': '720', '46': '1080',
    '82': '360 [3D]', '83': '480 [3D]', '84': '720 [3D]', '85': '1080p [3D]', '100': '360 [3D]',
    '101': '480 [3D]', '102': '720 [3D]', '92': '240', '93': '360', '94': '480', '95': '720',
    '96': '1080', '132': '240', '151': '72', '133': '240', '134': '360', '135': '480',
    '136': '720', '137': '1080', '138': '2160', '160': '144', '264': '1440',
    '298': '720', '299': '1080', '266': '2160', '167': '360', '168': '480', '169': '720',
    '170': '1080', '218': '480', '219': '480', '242': '240', '243': '360', '244': '480',
    '245': '480', '246': '480', '247': '720', '248': '1080', '271': '1440', '272': '2160',
    '302': '2160', '303': '1080', '308': '1440', '313': '2160', '315': '2160', '59': '480'}

    @classmethod
    def basic_encode(cls,mensagem):
        mensagem = base64.b64encode(mensagem.encode('utf-8', 'ignore')).decode('utf-8')
        return mensagem
    @classmethod
    def basic_decode(cls,mensagem):
        mensagem = base64.b64decode(mensagem).decode('utf-8')
        return mensagem    

    @classmethod
    def pick_source(cls,sources):
        return sources[0][1]

    @classmethod
    def __key(self, item):
        try:
            return int(re.search(r'(\d+)', item[0]).group(1))
        except:
            return 0
    
    @classmethod
    def _parse_gdocs(cls, html):
        urls = []
        if 'error' in html:
            reason = unquote_plus(re.findall('reason=([^&]+)', html)[0])
            raise ValueError(reason)
        value = unquote(re.findall('fmt_stream_map=([^&]+)', html)[0])
        items = value.split(',')
        for item in items:
            _source_itag, source_url = item.split('|')
            if isinstance(source_url, six.text_type) and six.PY2:  # @big change
                source_url = source_url.decode('unicode_escape').encode('utf-8')
            quality = cls.itag_map.get(_source_itag, 'Unknown Quality [%s]' % _source_itag)
            source_url = unquote(source_url)
            urls.append((quality, source_url))
        return urls
     
    @classmethod
    def resolve_url(cls,link):
        sources = []
        cookies = None
        referer = ''
        if 'drive.google.com' in link:
            referer = 'https://youtube.googleapis.com/'
            link = re.findall('/file/.*?/([^/]+)', link)[0]
            link = 'https://drive.google.com/get_video_info?docid=' + link
            response = requests.get(link,headers=cls.headers)
            cookies = response.cookies
            sources = cls._parse_gdocs(response.text)
        elif 'blogger.com/video.g?token=' in link:
            referer =  'https://www.youtube.com/'
            response = requests.get(link,headers=cls.headers)
            cookie = response.cookies
            source = re.findall(r'play_url.+?"(.+?)","format_id":(.+?)}', response.text)
            if source:
                sources = [(cls.itag_map.get(quality, 'Unknown Quality [%s]' % quality), stream.decode('unicode-escape') if six.PY2 else stream) for stream, quality in source]
        return sources, cookies, referer
    
    @classmethod
    def select_video(cls,sources):
        if sources:
            sources.sort(key=cls.__key, reverse=True)
            video = cls.pick_source(sources)
        else:
            video = ''
        return video

    # TESTE DE VIDEO
    @classmethod
    def teste_video(cls):
        sources, cookies, referer = cls.resolve_url('https://www.blogger.com/video.g?token=AD6v5dzIeW9tYcilTwBRv_zNGQQl0wBRUppMth1wzBbyaaIYoJXyt-PjCSbLiQ1-2_M6Ada7epQCazvwgBZCfMf6Vb76Eo6BXcvILO-mdXD9oD7eFxe74BpgwlLUCqcShYOJ1shSQcJU')
        video = cls.select_video(sources)


    # prepara os links
    @classmethod
    def find_video(cls,link):
        try:
            sources, cookies, referer = cls.resolve_url(link)
            video = cls.select_video(sources)
        except:
            cookies = None
            referer = None
            video = ''
        if video:
            if cookies:
                cookies_str = ";".join(["%s=%s"%(key,value) for key, value in cookies.items()])
                if referer:
                    video = video + '|User-Agent='+ quote(cls.user_agent) + '&Cookie=' + quote(cookies_str) + '&Referer='+ quote(referer)
                else:
                    video = video + '|User-Agent='+ quote(cls.user_agent) + '&Cookie=' + quote(cookies_str)
            else:
                if referer:
                    video = video + '|User-Agent='+ quote(cls.user_agent) + '&Referer='+ quote(referer)
                else:
                    video = video + '|User-Agent='+ quote(cls.user_agent)
        return video
    
    @classmethod
    def soup(cls,html):
        soup = BeautifulSoup(html, 'html.parser')
        return soup
    
    @classmethod
    def calendario(cls,day):
        days = 'segunda, terca, quarta, quinta, sexta, sabado, domingo'
        api = '%s/api/'%cls.site_anime
        headers = cls.headers
        #headers.update({'Referer': 'https://meuanime.io/api/'})
        payload = {'action': 'show_lancamentos'}
        animes = []
        try:
            r = requests.post(api,headers=headers,data=payload)
            d = r.json()
            for key in d[day].keys():
                anime = d[day][key]
                name = anime['title']
                iconimage = anime['thumbnail']
                url = anime['url']
                animes.append((name,iconimage,url))
        except:
            pass
        return animes

    @classmethod
    def todos_animes(cls,url=False):
        if not url:
            url = cls.site_anime + '/lista-de-animes-online'
        headers = cls.headers
        headers.update({'Referer': cls.site_anime + '/'})
        itens = []
        next = False
        page = ''
        try:
            r = requests.get(url,headers=headers)
            html = r.text
            soup = cls.soup(html)
            animes = soup.find('div', class_=lambda x: x.startswith('ultAnisContainer')).find_all('div',class_=lambda x: x.startswith('ultAnisContainerItem'))
            for anime in animes:
                a = anime.find('a')
                href = a.get('href')
                name = a.find('div', {'class': 'aniInfos'}).find('div', {'class': 'aniNome'}).text
                name = name.strip()
                name = name.replace('\n', '').replace('\r', '')
                div_img = a.find('div', {'class': 'aniImg'})
                img = div_img.find('img').get('data-lazy-src', '')
                eps = div_img.find('div', {'class': 'aniEps'}).text
                try:
                    ep = eps.split('E')[0].replace('\n', '').replace('\r', '').replace(' ', '')
                except:
                    ep = False
                if ep:
                    if int(ep) > 0:
                        itens.append((name,href,img,url))
            try:
                next = soup.find('div', {'paginacao'}).find('a', {'next page-numbers'}).get('href', '')
                if not next:
                    next = False
                else:
                    try:
                        page = next.split('/page/')[1]
                    except:
                        pass
                    try:
                        page = page.split('?')[0]
                    except:
                        pass                    
            except:
                next = False
        except:
            pass
        return itens, next, page

    @classmethod
    def episodios(cls,url):
        headers = cls.headers
        headers.update({'Referer': cls.site_anime + '/'})
        itens = []
        next = False
        page = ''
        try:
            r = requests.get(url,headers=headers)
            html = r.text
            soup = cls.soup(html)
            episodios = soup.find('section', class_=lambda x: x.startswith('anime_videos_section')).find_all('div',class_=lambda x: x.startswith('ultEpsContainerItem'))
            for episodio in episodios:
                a = episodio.find('a')
                href = a.get('href')
                try:
                    img = a.find('div', {'class':'epImg'}).find('img').get('data-lazy-src', '')
                except:
                    img = ''
                ep = a.find('div', {'class': 'epInfos'}).find('div', {'class': 'epNum'}).text
                ep = ep.strip()
                itens.append((ep,href,img,url))
            try:
                #next = soup.find('div', {'paginacao'}).find_all('a', {'class': 'page-numbers'})[-1].get('href', '')
                next = soup.find('div', {'paginacao'}).find_all('a', {'class': 'page-numbers'})
                next = [next_page for next_page in next if not 'last' in next_page['class']][-1].get('href', '')
                current = soup.find('div', {'paginacao'}).find('a', {'class': 'page-numbers current page-numbers'}).get('href', '')
                if not next:
                    next = False
                elif next == current:
                    next = False
                else:
                    try:
                        page = next.split('/page/')[1]
                    except:
                        pass
                    try:
                        page = page.split('?')[0]
                    except:
                        pass                    
            except:
                next = False
        except:
            pass     
        return itens, next, page

    @classmethod
    def resolve_player(cls,url):
        headers = cls.headers
        headers.update({'Referer': cls.referer_player})
        referer = url
        stream = ''
        try:
            r = requests.get(url,headers=headers)
            html = r.text
            match = re.search(r'"file":"([^"]+)"', html)
            if match:
                stream = match.group(1).replace('\/', '/') + '|User-Agent=' + quote(cls.user_agent) + '&Referer=' + quote(referer)
        except:
            pass
        return stream
    
    @classmethod
    def opcoes(cls,url,referer):
        headers = cls.headers
        headers.update({'Referer': referer})
        itens = []
        try:
            r = requests.get(url,headers=headers)
            if r.status_code == 200:
                html = r.text
                soup = cls.soup(html)
                players = soup.find_all('div', {'class': 'playerBox', 'id': lambda x: x and x.startswith('player_')})
                if players:
                    for op, player in enumerate(players):
                        op = op + 1
                        name = 'OPÇÃO %s'%str(op)
                        # try:
                        #     script = player.find('div', {'id': lambda x: x and x.startswith('player_')}).find('script', text=re.compile('file: ".*"'))
                        #     try:
                        #         stream = re.findall('file: "(.*)"', str(script))[0]
                        #     except:
                        #         stream = ''
                        #     if not stream:
                        #         stream = re.findall('file: "(.*)"', script.text)[0]                    
                        # except:
                        #     try:
                        #         stream = player.find('video').get('src', '')
                        #     except:
                        #         stream = ''
                        try:
                            stream = re.findall(r'file:.+?"(.*?)"', str(player))[0]
                        except:
                            stream = ''
                        if not stream:
                            try:
                                stream = re.findall(r'src="([^"]+\.mp4)"', str(player))[0]
                            except:
                                stream = ''                          
                        if not stream:
                            stream = player.find('a').get('href', '')
                        if '.mp4' in stream:
                            stream = stream + '|User-Agent='+ quote(cls.user_agent) + '&Referer='+ quote(cls.site_anime + '/')
                            itens.append((name,stream))
                        else:
                            itens.append((name,stream))
        except:
            pass
        return itens
    
    @classmethod
    def pesquisa(cls,url=None,pesquisa=None):
        itens = []
        next = False
        page = ''
        if pesquisa:
            url = cls.site_anime + '/?s=' + quote(pesquisa).replace('%20', '+')
        headers = cls.headers
        headers.update({'Referer': cls.site_anime + '/'})            
        try:
            r = requests.get(url,headers=headers)
            html = r.text
            soup = cls.soup(html)
            animes = soup.find('div', class_=lambda x: x.startswith('busca_container')).find_all('div',class_=lambda x: x.startswith('ultAnisContainerItem'))
            for anime in animes:
                a = anime.find('a')
                href = a.get('href')
                name = a.find('div', {'class': 'aniInfos'}).find('div', {'class': 'aniNome'}).text
                name = name.strip()
                name = name.replace('\n', '').replace('\r', '')
                div_img = a.find('div', {'class': 'aniImg'})
                img = div_img.find('img').get('data-lazy-src', '')
                itens.append((name,href,img,url))
            try:
                next = soup.find('div', {'paginacao'}).find('a', {'next page-numbers'}).get('href', '')
                if not next:
                    next = False
                else:
                    try:
                        page = next.split('/page/')[1]
                    except:
                        pass
                    try:
                        page = page.split('?')[0]
                    except:
                        pass
            except:
                next = False                 
        except:
            pass
        return itens, next, page

if kodi_mode:
    plugin = sys.argv[0]
    handle = int(sys.argv[1])
    addon = xbmcaddon.Addon()
    addonname = addon.getAddonInfo('name')
    icon = addon.getAddonInfo('icon')
    translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
    profile = translate(addon.getAddonInfo('profile')) if six.PY3 else translate(addon.getAddonInfo('profile')).decode('utf-8')
    home = translate(addon.getAddonInfo('path')) if six.PY3 else translate(addon.getAddonInfo('path')).decode('utf-8')
    next_icon = os.path.join(home, 'seguinte.png')
    search_icon = os.path.join(home, 'search.png')
    dialog = xbmcgui.Dialog()
       
  

    def route(f):
        action_f = f.__name__
        params_dict = {}
        param_string = sys.argv[2]
        if param_string:
            split_commands = param_string[param_string.find('?') + 1:].split('&')
            for command in split_commands:
                if len(command) > 0:
                    if "=" in command:
                        split_command = command.split('=')
                        key = split_command[0]
                        value = split_command[1]
                        try:
                            key = unquote_plus(key)
                        except:
                            pass
                        try:
                            value = unquote_plus(value)
                        except:
                            pass
                        params_dict[key] = value
                    else:
                        params_dict[command] = ""
        action = params_dict.get('action')
        if action is None and action_f == 'main':
            f()
        elif action == action_f:
            f(params_dict)

    def infoDialog(message, heading=addonname, iconimage='', time=3000, sound=False):
        if iconimage == '':
            iconimage = icon
        elif iconimage == 'INFO':
            iconimage = xbmcgui.NOTIFICATION_INFO
        elif iconimage == 'WARNING':
            iconimage = xbmcgui.NOTIFICATION_WARNING
        elif iconimage == 'ERROR':
            iconimage = xbmcgui.NOTIFICATION_ERROR
        dialog.notification(heading, message, iconimage, time, sound=sound)

    def to_unicode(text, encoding='utf-8', errors='strict'):
        """Force text to unicode"""
        if isinstance(text, bytes):
            return text.decode(encoding, errors=errors)
        return text

    def get_search_string(heading='', message=''):
        """Ask the user for a search string"""
        search_string = None
        keyboard = xbmc.Keyboard(message, heading)
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_string = to_unicode(keyboard.getText())
        return search_string

    def search():
        vq = get_search_string(heading='Digite a pesquisa', message="")        
        if ( not vq ): return False
        return vq                

    def SetView(name):
        if name == 'Wall':
            try:
                xbmc.executebuiltin('Container.SetViewMode(500)')
            except:
                pass
        elif name == 'List':
            try:
                xbmc.executebuiltin('Container.SetViewMode(50)')
            except:
                pass
        elif name == 'Poster':
            try:
                xbmc.executebuiltin('Container.SetViewMode(51)')
            except:
                pass
        elif name == 'Shift':
            try:
                xbmc.executebuiltin('Container.SetViewMode(53)')
            except:
                pass
        elif name == 'InfoWall':
            try:
                xbmc.executebuiltin('Container.SetViewMode(54)')
            except:
                pass
        elif name == 'WideList':
            try:
                xbmc.executebuiltin('Container.SetViewMode(55)')
            except:
                pass
        elif name == 'Fanart':
            try:
                xbmc.executebuiltin('Container.SetViewMode(502)')
            except:
                pass

    def get_kversion():
        full_version_info = xbmc.getInfoLabel('System.BuildVersion')
        baseversion = full_version_info.split(".")
        intbase = int(baseversion[0])
        return intbase              

    def get_url(params):
        if params:
            url = '%s?%s'%(plugin, urlencode(params))
        else:
            url = ''
        return url   
  

    def item(params,folder=True):
        u = get_url(params)
        if not u:
            u = ''
        name = params.get("name")
        if name:
            name = name
        else:
            name = 'Unknow'
        iconimage = params.get("iconimage")
        if not iconimage:
            iconimage = icon
        fanart = params.get("fanart")
        if not fanart:
            fanart = ''
        description = params.get("description")
        if not description:
            description = ''           
        playable = params.get("playable")
        liz = xbmcgui.ListItem(name)
        liz.setArt({'fanart': fanart, 'thumb': iconimage, 'icon': "DefaultFolder.png"})
        if get_kversion() > 19:
            info = liz.getVideoInfoTag()
            info.setTitle(name)
            info.setMediaType('video')
            info.setPlot(description)
        else:
            liz.setInfo(type="Video", infoLabels={"Title": name, 'mediatype': 'video', "Plot": description})                                              
        if playable:
            if playable == 'true':
                liz.setProperty('IsPlayable', 'true')
        ok = xbmcplugin.addDirectoryItem(handle=handle, url=u, listitem=liz, isFolder=folder)
        return ok


    @route
    def main(): 
        xbmcplugin.setContent(handle, 'tvshows')
        item({'name': '[B]PESQUISAR[/B]', 'action': 'pesquisa_anime','iconimage': search_icon},folder=True)
        item({'name': '[B]CALENDÁRIO[/B]', 'action': 'calendario','iconimage': icon},folder=True)
        item({'name': '[B]TODOS OS ANIMES[/B]', 'action': 'todos_animes','iconimage': icon},folder=True)
        xbmcplugin.endOfDirectory(handle)
        SetView('WideList')

    @route
    def pesquisa_anime(param):
        pesquisa = param.get('pesquisa', '')
        next = param.get('next', False)
        if not pesquisa:
            pesquisa = search()
            if pesquisa:
                itens, next, page = scrape.pesquisa(next,pesquisa=pesquisa)
            else:
                return
        else:
            itens, next, page = scrape.pesquisa(next,pesquisa=False)
        if itens:
            xbmcplugin.setContent(handle, 'tvshows')
            for anime in itens:
                name,href,iconimage,referer = anime
                try:
                    name = name.replace('&#8211;', '-')
                except:
                    pass
                name = '[B]' + name.upper() + '[/B]'
                item({'name': name.encode('utf-8', 'ignore'), 'action': 'episodios', 'url': href, 'iconimage': iconimage},folder=True)
            if next:
                name = '[B]PAGINA %s[/B]'%str(page)
                item({'name': name, 'action': 'pesquisa_anime', 'pesquisa': pesquisa.encode('utf-8', 'ignore'), 'next': next, 'iconimage': next_icon},folder=True)
        xbmcplugin.endOfDirectory(handle)
        SetView('WideList')                                            


    @route
    def calendario(param):
        day = param.get('day', False)
        days = ['domingo', 'segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado']
        xbmcplugin.setContent(handle, 'tvshows')
        if not day:
            for day in days:
                if day == 'terca':
                    name = 'TERÇA'
                elif day == 'sabado':
                    name = 'SÁBADO'
                else:
                    name = day.upper()
                name = '[B]' + name + '[/B]'                
                item({'name': name, 'action': 'calendario','day': day, 'iconimage': icon},folder=True)
        else:
            if day:
                animes = scrape.calendario(day)
                for anime in animes:
                    name,iconimage,url = anime
                    try:
                        name = name.replace('&#8211;', '-')
                    except:
                        pass                    
                    name = '[B]' + name.upper() + '[/B]'
                    item({'name': name.encode('utf-8', 'ignore'), 'action': 'episodios', 'url': url, 'iconimage': iconimage},folder=True)
        xbmcplugin.endOfDirectory(handle)
        SetView('WideList')

    @route
    def todos_animes(param):
        next = param.get('next', False)
        itens, next, page = scrape.todos_animes(next)
        xbmcplugin.setContent(handle, 'tvshows')
        if itens:
            for anime in itens:
                name,href,iconimage,referer = anime
                try:
                    name = name.replace('&#8211;', '-')
                except:
                    pass
                name = '[B]' + name.upper() + '[/B]'
                item({'name': name.encode('utf-8', 'ignore'), 'action': 'episodios', 'url': href, 'iconimage': iconimage},folder=True)
        if next:
            name = '[B]PAGINA %s[/B]'%str(page)
            item({'name': name, 'action': 'todos_animes', 'next': next, 'iconimage': next_icon},folder=True)
        xbmcplugin.endOfDirectory(handle)
        SetView('WideList')

    @route
    def episodios(param):
        next = param.get('next', param.get('url', False))
        itens, next, page = scrape.episodios(next)
        if itens:
            for episodio in itens:
                name,href,iconimage,referer = episodio
                name = '[B]' + name.upper() + '[/B]'
                item({'name': name.encode('utf-8', 'ignore'), 'action': 'play', 'url': href, 'referer': referer, 'iconimage': iconimage, 'playable': 'true'},folder=False)
            if next:
                name = '[B]PAGINA %s[/B]'%str(page)
                item({'name': name, 'action': 'episodios', 'next': next, 'iconimage': next_icon},folder=True)
            xbmcplugin.endOfDirectory(handle)
            SetView('WideList')
        else:
            infoDialog('NENHUM EPISODIO AINDA', iconimage='INFO')  

    @route
    def play(param):
        url = param.get('url', '')              
        referer = param.get('referer', '')
        playable = param.get('playable', '')
        name = param.get('name', 'Aguia Animes')
        iconimage = param.get('iconimage', '')
        if url and referer:
            itens = scrape.opcoes(url,referer)
            if itens:
                items_options = [name2 for name2,href in itens] 
                op = dialog.select('SELECIONE UMA OPÇÃO', items_options)
                if op >= 0:
                    stream = itens[op][1]
                    if not '.mp4' in stream:
                        stream = scrape.resolve_player(stream)
                    if stream:
                        liz = xbmcgui.ListItem(name)
                        liz.setPath(stream)
                        liz.setArt({'thumb': iconimage, 'icon': iconimage})
                        description = ''
                        if get_kversion() > 19:
                            info = liz.getVideoInfoTag()
                            info.setTitle(name)
                            info.setMediaType('video')
                            info.setPlot(description)
                        else:           
                            liz.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
                        if not playable:
                            xbmc.Player().play(item=stream, listitem=liz)
                        else:
                            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
                    else:
                        infoDialog('STREAMING INDISPONIVEL', iconimage='INFO')
            else:
                infoDialog('STREAMING INDISPONIVEL', iconimage='INFO')                                                                                                  